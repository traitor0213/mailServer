const express = require("express")
const fs = require("fs")
const app = express()

app.get("/getMailData", async (req, res) => {
    mailAddress = req.query.address
    try {
        emailContent = fs.readFileSync("../data/" + mailAddress + "/received.json")
        res.send(emailContent.toString())
    } catch {
        res.send('{"status": "fileOpenError"}')
    }
})

app.listen(3000)